package com.dp2k.mybutton2;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.graphics.Typeface;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Random;

public class MainActivity extends AppCompatActivity {

    int min = 1;
    int max = 10;
    int min2 = 0;
    int max2 = 2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Random r = new Random();
        int RandomNumber1 = r.nextInt(max-min+1)+min;
        int RandomNumber2 = r.nextInt(max-min+1)+min;

        Typeface typeface = Typeface.createFromAsset(getAssets(), "fonts/EraserDust.ttf");

      //  TextView TextView2 = (TextView)findViewById(R.id.resultnum);
      //  TextView2.setText("btn");

        TextView TextView0 = (TextView)findViewById(R.id.number1);
        TextView0.setTypeface(typeface);
        TextView0.setText(""+RandomNumber1);
        TextView TextView1 = (TextView)findViewById(R.id.number2);
        TextView1.setTypeface(typeface);
        TextView1.setText(""+RandomNumber2);


        final int Total=RandomNumber1+RandomNumber2;
        int TotalWrong0=Total+2;
        int TotalWrong1=Total+4;

        List<Integer> objects = new ArrayList<Integer>();
        objects.add(Total);
        objects.add(TotalWrong0);
        objects.add(TotalWrong1);
        Collections.shuffle(objects);
        List<Button> buttons = new ArrayList<Button>();
        buttons.add((Button)findViewById(R.id.btn0));
        buttons.add((Button)findViewById(R.id.btn1));
        buttons.add((Button)findViewById(R.id.btn2));

        final Button Button0 = (Button)findViewById(R.id.btn0);
     //   Button0.setText(""+Total);

        final Button Button1 = (Button)findViewById(R.id.btn1);

    //    Button1.setText(""+TotalWrong0);
        final Button Button2 = (Button)findViewById(R.id.btn2);
    //    Button2.setText(""+TotalWrong1);

        final TextView TextView2 = (TextView)findViewById(R.id.resultnum);
        TextView2.setTypeface(typeface);


        for (int i = 0; i < objects.size(); i++) {
            buttons.get(i).setText(objects.get(i).toString());
        }

        Button0.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                int test1 = Integer.parseInt(Button0.getText().toString());
                if (test1 == Total)
                {
                    TextView2.setText("Right");
                }
                else if (test1!=Total)
                {
                    TextView2.setText("Wrong");
                }

            }
        });

        Button1.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                int test1 = Integer.parseInt(Button1.getText().toString());
                if (test1 == Total)
                {
                    TextView TextView2 = (TextView)findViewById(R.id.resultnum);
                    TextView2.setText("Right");
                }
                else if (test1!=Total)
                {
                    TextView TextView2 = (TextView)findViewById(R.id.resultnum);
                    TextView2.setText("Wrong");
                }

            }
        });

        Button2.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                int test1 = Integer.parseInt(Button2.getText().toString());
                if (test1 == Total)
                {
                    TextView TextView2 = (TextView)findViewById(R.id.resultnum);
                    TextView2.setText("Right");
                }
                else if (test1!=Total)
                {
                    TextView TextView2 = (TextView)findViewById(R.id.resultnum);
                    TextView2.setText("Wrong");
                }

            }
        });


    }
}
