package com.dp2k.mybutton2;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.Random;

public class MainActivity extends AppCompatActivity {

    int min = 1;
    int max = 10;
    int min2 = 0;
    int max2 = 2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Random r = new Random();
        int RandomNumber1 = r.nextInt(max-min+1)+min;
        int RandomNumber2 = r.nextInt(max-min+1)+min;

      //  TextView TextView2 = (TextView)findViewById(R.id.resultnum);
      //  TextView2.setText("btn");

        TextView TextView0 = (TextView)findViewById(R.id.number1);
        TextView0.setText(""+RandomNumber1);
        TextView TextView1 = (TextView)findViewById(R.id.number2);
        TextView1.setText(""+RandomNumber2);


        int Total=RandomNumber1+RandomNumber2;
        int TotalWrong0=Total+2;
        int TotalWrong1=Total+4;

        Button Button0 = (Button)findViewById(R.id.btn0);
        Button0.setText(""+Total);

        Button Button1 = (Button)findViewById(R.id.btn1);
        Button1.setText(""+TotalWrong0);

        Button Button2 = (Button)findViewById(R.id.btn2);
        Button2.setText(""+TotalWrong1);


    }
}
